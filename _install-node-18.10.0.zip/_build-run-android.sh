#!/bin/bash

echo "******************************************"
echo "COMPILAR Y EJECUTAR APLICACION EN ANDROID"
echo "******************************************\n\n"


sh _build.sh
sh _run-android.sh

