#!/bin/bash

echo "******************************************"
echo "COMPILAR APLICACION"
echo "******************************************\n\n"


ionic build
