#!/bin/bash

sudo apt-get -y update
sudo apt-get -y install nodejs
sudo apt-get -y install npm
nvm use 18.10.0
nvm alias default 18.10.0
sudo npm install -g angular-cli
sudo npm i --location=global @angular/cli@16.1.7
npm i --location=global @capacitor/app@latest
npm i --location=global @capacitor/cli@latest
npm i --location=global @capacitor/core@latest
npm i --location=global @capacitor/haptics@latest
npm i --location=global @capacitor/keyboard@latest
npm i --location=global @capacitor/status-bar@latest
npm i --location=global @ionic/cli@7.1.1
npm i --location=global cordova-res@latest
npm i --location=global cordova@latest
npm i --location=global corepack@latest
npm i --location=global native-run@1.7.2
npm i --location=global npm@9.8.1
npm i --location=global rxjs@7.4.0
npm i --location=global typescript@5.1.6

