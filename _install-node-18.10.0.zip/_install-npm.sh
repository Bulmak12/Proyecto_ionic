#!/bin/bash

echo "******************************************"
echo "DESCARGAR E INSTALAR PAQUETES DE NODE"
echo "******************************************\n\n"


npm install

