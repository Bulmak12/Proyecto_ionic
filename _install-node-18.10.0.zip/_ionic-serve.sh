#!/bin/bash

echo "******************************************"
echo "EJECUTAR APLICACION EN NAVEGADOR"
echo "******************************************\n\n"

ionic serve