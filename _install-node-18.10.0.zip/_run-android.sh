#!/bin/bash

echo "******************************************"
echo "EJECUTAR APLICACION"
echo "******************************************\n\n"

ionic cap run android -l --external --host=192.168.100.15 --port=8100 --target R58T614VCGP
