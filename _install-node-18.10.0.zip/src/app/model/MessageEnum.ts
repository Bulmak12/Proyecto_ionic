export enum MessageEnum {
    OK = 0,
    YES = 1,
    NO = 2,
    CANCEL = 3
}